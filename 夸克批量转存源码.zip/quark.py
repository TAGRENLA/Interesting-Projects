from tkinter import *

from quarkmvc import QuarkModel, Quark, QuarkController

class MainApp(Tk):
    def __init__(self) -> None:
        super().__init__()
        self.model = QuarkModel()
        self.view = Quark(self)
        self.coltroller = QuarkController(self.model, self.view)
        self.mainloop()

if __name__ == '__main__':
    MainApp()