import time
import json
import random

from common import request,common_params,logger, get_cookie

# ss = request()
# logger = logger()
# common_params().pop('__dt',None)
# common_params().pop('__t',None)


class QuarkShare:
    def __init__(self, cookie:str) -> None:
        self.cookie = cookie
        self.init()

    def init(self):
        self.ss = request(self.cookie)
        self.common_params = common_params()
        self.common_params.pop('__dt',None)
        self.common_params.pop('__dt',None)
        self.logger = logger()
    # 3.8版本不兼容
    # def get_all_file(self, fid: str, page: str='1', size: str='50') -> list | bool:
    def get_all_file(self, fid: str, page: str='1', size: str='50'):
        '''
        获取指定文件夹下的所有文件信息
        fid:: 指定文件夹的fid，fid为0时，获取主页目录
        return:: 返回所有文件的具体信息：fid，filename，isfile
        当fid不存在或者目录下没有文件时，会返回空list
        '''
        url = 'https://drive-pc.quark.cn/1/clouddrive/file/sort'
        params = {
            'pdir_fid': fid,
            '_page': page,
            '_size': size,
            '_fetch_total': 1,
            '_fetch_sub_dirs': 0,
            '_sort': ''
        }
        params.update(self.common_params)
        file_lst = []
        try:
            res = self.ss.get(url, params=params)
        except:
            return file_lst
        resdata = res.json()
        if res.status_code == 200 and resdata['code'] == 0:
            files = resdata['data']['list']
            # 当files为空时，代表当前文件夹下面没有文件，或者当前fid是文件的fid,或者fid不存在
            total = resdata['metadata']['_total']
            file_lst = [(file['fid'], file['file_name'], file['file'], file['pdir_fid'], total) for file in files]
            # print(f'当前目录下共有{total}个文件')
        else:
            self.logger.error(resdata['message'])

        return file_lst

    # get share_id task_id
    def get_file_share_id(self, info:tuple) -> tuple:
        '''
        当给定的fid为文件id时，获取share_id
        当给定的fid为文件夹id时，获取task_id
        '''
        url = 'https://drive-pc.quark.cn/1/clouddrive/share'
        params = self.common_params
        data = {
            'fid_list':[info[0]],
            'title':info[1],
            'url_type':1,
            'expired_type':1
        }
        res = self.ss.post(url, data=json.dumps(data), params=params)
        resdata = res.json()
        if res.status_code == 200 and resdata['code'] == 0:
            # 分享的是文件
            if 'task_resp' in resdata['data']:
                data = resdata['data']['task_resp']
                # 文件违规或其他，导致不能分享
                if data['code'] != 0:
                    return (None, None)
                share_id = data['data']['share_id']
                success_count = data['data']['creation_snapshot']['success_count']
                if success_count:
                    print('share file success,get share url later.')
                return (share_id,success_count)

            else:
                # 分享的是文件夹
                
                task_id = resdata['data']['task_id']
                success_count = 1
                return (task_id,success_count)
            
        else:
            self.logger.error(resdata['message'])
            print('file',res.json())
            return (None,None)

    def get_dir_share_id(self, task_id:str) -> tuple:
        '''
        获取文件夹的share id
        文件夹的shareid得多获取几次，最少两次请求
        '''
        url = 'https://drive-pc.quark.cn/1/clouddrive/task'
        params = {
            'task_id': task_id,
            'retry_index': 0
        }
        params.update(self.common_params)
        retry_counts = 100
        # 错误码41002分享文件个数超过限制，分享失败
        for i in range(1,retry_counts):
            params['retry_index'] = i
            res = self.ss.get(url,params=params)
            resdata = res.json()
            if res.status_code == 200 and resdata['code'] == 0:
                data = resdata['data']
                if data.get('creation_snapshot',None):
                    success_count = data['creation_snapshot']['success_count']
                    print('share dir success,get share url later.')
                    return (data['share_id'],success_count)
                else:
                    print(f'获取share_id失败，正在进行第{i}次尝试')
                    time.sleep(0.8)
            elif res.status_code == 404 or resdata['code'] == 41002:
                # 文件个数超过分享个数
                self.logger.error(resdata['message'])
                return (None,None)
            else:
                self.logger.error(resdata['message'])
                return (None,None)
                
    # def get_share_url(self, info:tuple, succ_fname:str) -> str | None: 3.8 not support
    def get_share_url(self, info:tuple, succ_fname:str) -> str:
        '''
        文件通过share_id获取分享链接
        '''
        url = 'https://drive-pc.quark.cn/1/clouddrive/share/password'
        share_id,success_count = info
        if not success_count:
            print('share fail')
            return
        params = self.common_params
        data = {
            'share_id':share_id
        }
        res = self.ss.post(url,data=json.dumps(data),params=params)
        resdata = res.json()
        if res.status_code == 200 and resdata['code'] == 0:
            data = resdata['data']
            share_url,title,pwd_id = (data['share_url'], data['title'], data['pwd_id'])
            with open(succ_fname,'a',encoding='utf8') as f:
                content = '##'.join([title, share_url]) + '\n'
                f.write(content)
                print('success: ', title)
                return share_url
        else:
            self.logger.error(resdata['message'])
            print(res.json())
            return None

    def recent_save(self, size:int=30):
        '''
        获取最近保存的内容
        size::最近保存的文件数
        '''
        url = 'https://drive-pc.quark.cn/1/clouddrive/file/category'
        params = {
            '_size': size,
            'labels': 'SAVE_AS_TOP_LAYER',
            'pr': 'ucpro',
            'fr': 'pc'
        }
        params.update(self.common_params)
        res = self.ss.get(url,params=params)
        resdata = res.json()
        if res.status_code == 200 and resdata['code'] == 0:
            r_lst = resdata['data']['list']
            return [(item['fid'], item['file_name'], item['file']) for item in r_lst]
        else:
            self.logger.error(resdata['message'])

    # def recent_share(self, page: str|int=1, size: str|int=50): 3.8 not support
    def recent_share(self, page: int=1, size: int=50):
        '''
        获取最近分享的内容
        page:: 获取第几页的数据，默认为1
        size:: 每页展示多少条数据，默认为50
        '''
        url = 'https://drive-pc.quark.cn/1/clouddrive/share/mypage/detail'
        params = {
            '_page': page,
            '_size': size,
            '_order_field': 'created_at',
            '_order_typ': 'desc',
            '_fetch_total': 1,
            '_fetch_notify_follow': 1
        }
        params.update(self.common_params)
        res = self.ss.get(url, params=params)
        resdata = res.json()
        if res.status_code == 200 and resdata['code'] == 0:
            lst = resdata['data']['list']
            l = []
            for item in lst:
                title = item['title']
                share_url = item['share_url']
                click_pv = item['click_pv']
                print(item['share_url'])
                l.append(item['share_url'])
            print(','.join(l))
            print(l)
        else:
            self.logger.error(resdata['message'])

    def autoshare(self, fid, duration:int=5):
        '''
        该函数用于分享文件夹下的所有文件，fid为文件夹的fid
        ::duration 分享间隔时间 
        '''
        print('正在分享--')
        succ_name = '批量分享-27.txt'
        file_lst = self.get_all_file(fid)
        for file in file_lst:
            if file[2]:
                file = self.get_file_share_id(file)
            else:
                task_id, _ = self.get_file_share_id(file)
                file = self.get_dir_share_id(task_id)
            self.get_share_url(file, succ_name)
            time.sleep(random.randint(3, duration if duration > 3 else duration + 3))

    def single_file_share(self, fid, fname, is_file, succ_name=None):
            '''
            该函数用于分享单个文件，fid为指定文件的fid
            '''
            print(f'正在分享--{fname}')
            succ_name = succ_name or '批量分享--' + str(time.time()).split('.')[1] + '.txt'
            if is_file:
                file = self.get_file_share_id((fid, fname, is_file))
            else:
                task_id, _ = self.get_file_share_id((fid, fname, is_file))
                file = self.get_dir_share_id(task_id)
            return self.get_share_url(file, succ_name)

if __name__ == '__main__':
    # lst =recent_save()
    # main('5dc6cb0f7ed8458ba9459e787c9453a2')
    # recent_share()
    # get_all_file('ab4a98c7')
    # get_share_url(get_dir_share_id('40e20dcf1b6f454bba2b1652fe43e2da'),'批量分享-1.txt')
    cookie = get_cookie()
    qs = QuarkShare(cookie)
    qs.recent_share()