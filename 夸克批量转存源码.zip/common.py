import time
import random
import logging
import threading
import os

from http.cookies import SimpleCookie

import requests


import os
import sys

# 获取当前脚本的绝对路径
def get_abs_path():
    if getattr(sys, 'frozen', False):
        application_path = sys._MEIPASS
    else:
        application_path = os.path.dirname(os.path.abspath(__file__))
    return application_path



SOFT_INFO = {
    'version': '1.0.0',
    'author': 'huahua',
    'wechat': 'ly428859'
}

class MyThread(threading.Thread):
    '''
    返回线程函数的结果的类
    '''
    def run(self):
        if self._target is not None:
            self._return = self._target(*self._args, **self._kwargs)
    
    def join(self, timeout):
        super().join(timeout)
        return self._return

def request(cookies:str = '', proxy:str=''):
    '''
    使用session方法来持久化cookie
    :proxy 代理 218.6.120.111:7777
    '''
    headers = {
        'User-Agent':'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/123.0.0.0 Safari/537.36',
        'Referer':'https://pan.quark.cn/',
        'Origin':'https://pan.quark.cn',
        'Content_Type':'application/json'
    }

    cookie_obj = SimpleCookie()
    cookie_obj.load(cookies)
    cookie_dict = {key: morsel.value for key, morsel in cookie_obj.items()}

    ss = requests.session()
    ss.cookies.update(cookie_dict)
    ss.headers.update(headers)

    if proxy:
        if ':' not in proxy:
            print('添加代理失败，请检查代理格式：218.6.120.111:7777')
            return ss
        
        ip, port = proxy.split(':')
        proxies = {
            'http': f'http://{ip}:{port}',
            'https': f'http://{ip}:{port}',
            # 'https': f'https://{ip}:{port}',
        }
        ss.proxies.update(proxies)
    else:
        print('当前未设置代理')

    return ss

def common_params():
    t = str(time.time()*1000).split('.')[0]
    dt = random.randint(1000,10000)
    params = {
        'pr':'ucpro',
        'fr':'pc',
        'uc_param_str':'',
        '__dt':dt,
        '__t':t
    }
    return params

def logger():
    # 创建一个logger
    logger = logging.getLogger("error_logger")
    # 设置logger的级别为ERROR, 意味着只有ERROR (还有CRITICAL) 级别的信息会被记录下
    logger.setLevel(logging.ERROR)

    # 创建一个handler，用于写入日志文件
    fh = logging.FileHandler('logfile.txt')
    fh.setLevel(logging.ERROR)  

    # 定义handler的输出格式
    formatter = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s')
    fh.setFormatter(formatter)

    # 给logger添加handler
    logger.addHandler(fh)
    return logger

def get_cookie(cookie:str='') -> str:
    '''
    获取用户的cookie
    '''
    # 用户输入cookie
    if cookie:
        update_cookie(cookie)
        return cookie
    # 用户没有输入cookie，从本地获取，本地没有返回None
    else:
        return get_lcookie()
    
def get_lcookie() -> str:
    '''
    获取本地cookie
    '''
    if not os.path.exists('config.ini'):
        with open('config.ini', 'w', encoding='utf8') as f:
            f.writelines(['[cookie]\n', 'cookies = '])

    with open('config.ini', 'r', encoding='utf8') as f:
        lines = f.readlines()
        if len(lines) > 1 and 'cookie' in lines[1]:
            lcookie = lines[1].split('cookies =')[1].strip()
            return lcookie
    return ''

def update_cookie(cookie:str):
    '''
    不做判断，暴力写入
    '''
    with open('config.ini', 'w', encoding='utf8') as f:
        f.writelines(['[cookie]\n', f'cookies = {cookie}'])

def get_soft_info() -> str:
    headers = {
    'User-Agent':'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/123.0.0.0 Safari/537.36',
    }
    url = 'https://gitee.com/hxb276/fengmianapi/raw/main/quarkinfo.json'
    try:
        res = requests.get(url, headers=headers, timeout=(8, 8))
        data = res.json()
    except:
        data = SOFT_INFO
    finally:
        info = ''
        for k, v in data.items():
            info += k + ': ' + v + '\n'
        return info