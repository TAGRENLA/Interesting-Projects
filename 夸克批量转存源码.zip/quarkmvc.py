import time
from tkinter import *
from tkinter import ttk, messagebox,Text,filedialog
import queue
import threading
import re
import math
import os

from autosave import QuarkSave
from autoshare import QuarkShare
from common import get_cookie, get_soft_info, get_abs_path, MyThread


class Quark:
    def __init__(self, root) -> None:
        self.root = root
        # self.root.withdraw()  # 隐藏 Tkinter 主窗口
        self.root.title('夸克批量转存分享-V1.0.0')
        self.widget_width = 8
        self.interface()
        # 显示软件信息
        self.__update_log_interface(get_soft_info())

        screen_w = self.root.winfo_screenwidth()
        screen_h = self.root.winfo_screenheight()

        center_x = int((screen_w - 1080) / 2)
        center_y = int((screen_h - 615) / 2)
        self.root.geometry(f'1080x615+{center_x}+{center_y}')
        self.root.resizable(False, False)
        # 提前设置图标，会出现闪烁小窗口
        self.root.iconbitmap(os.path.join(get_abs_path(), "59.ico"))
        # self.root.deiconify()
   
    def interface(self):
        
        self.style = ttk.Style()
        self.style.theme_use('default')
        self.style.map("Treeview", foreground=self._fixed_map("foreground"), background=self._fixed_map("background"))

        content = ttk.Frame(self.root)
        op_frame = ttk.Frame(content)
        log_frame = ttk.Frame(content)

        self.cookie_var = StringVar()
        cookie_lable = ttk.Label(op_frame, text="夸克cookies：")
        self.cookie_entry = ttk.Entry(op_frame, textvariable=self.cookie_var)
        self.login_btn = ttk.Button(op_frame, text='登录', width=self.widget_width)
        self.share_btn = ttk.Button(op_frame, text='批量分享', width=self.widget_width)
        self.study_btn = ttk.Button(op_frame, text='教程', width=self.widget_width)

        # 创建一个Text控件,显示操作信息
        scrollbar = Scrollbar(self.root)
        scrollbar.grid(row=0, column=1, sticky='ns')
        self.log_output = Text(log_frame, 
                               width=52, 
                               height=33, 
                               background='black', 
                               foreground='green', 
                               cursor='spider',
                               padx=10,
                               pady=5,
                               spacing1=5,
                               yscrollcommand=scrollbar.set
                               )
        scrollbar.config(command=self.log_output.yview)

        content.grid(column=0, row=0)
        op_frame.grid(column=0, row=0, padx=2)
        log_frame.grid(column=1, row=0)

        cookie_lable.grid(column=0, row=0)
        self.cookie_entry.grid(column=1, row=0, columnspan=5, sticky='nsew')
        self.login_btn.grid(column=6, row=0)
        self.share_btn.grid(column=7, row=0)
        self.study_btn.grid(column=8, row=0)
        
        self.log_output.grid(column=0, row=0)

        # op_frame 第二行
        cur_dir_label = ttk.Label(op_frame, text='当前目录：')
        self.cur_dir_var = StringVar()
        self.cur_dir_entry = ttk.Entry(op_frame, textvariable=self.cur_dir_var, width=15)
        pfid_label = ttk.Label(op_frame, text='pfid:', width=5, padding=0)
        self.pfid_var = StringVar()
        self.cur_pfid = ttk.Entry(op_frame, textvariable=self.pfid_var, width=self.widget_width)
        page_label = ttk.Label(op_frame,  text='页数:', width=5)
        self.page_var = StringVar()
        self.page_entry = ttk.Entry(op_frame, textvariable=self.page_var, width=self.widget_width)
        page_count_label = ttk.Label(op_frame, text='每页数量:', width=8)
        self.page_count_var = StringVar()
        page_count_entry = ttk.Entry(op_frame, textvariable=self.page_count_var, width=self.widget_width)
        self.return_btn = ttk.Button(op_frame, text='返回首页', width=self.widget_width)
        share_delay_label = ttk.Label(op_frame, text='分享延迟', anchor='w')
        self.share_delay_var = StringVar()
        share_delay_entry = ttk.Entry(op_frame, textvariable=self.share_delay_var, width=self.widget_width)
        self.return_prepage_btn = ttk.Button(op_frame, text='返回上页', width=self.widget_width)
        self.share_recent_save_btn = ttk.Button(op_frame, text='分享最近保存', width=self.widget_width*1.5)
        self.export_recent_share_btn = ttk.Button(op_frame, text='导出最近分享', width=self.widget_width*1.5)

        cur_dir_label.grid(column=0, row=1)
        self.cur_dir_entry.grid(column=1, row=1, ipadx=0)
        pfid_label.grid(column=2, row=1, sticky=E)
        self.cur_pfid.grid(column=3, row=1, sticky='w')
        page_label.grid(column=4, row=1, sticky='e')
        self.page_entry.grid(column=5, row=1, sticky='w')
        page_count_label.grid(column=6, row=1)
        page_count_entry.grid(column=7, row=1)
        self.return_btn.grid(column=8, row=1)
        share_delay_label.grid(column=0, row=2)
        share_delay_entry.grid(column=1, row=2, sticky='w')
        self.return_prepage_btn.grid(column=8, row=2)
        self.share_recent_save_btn.grid(column=6, row=2, columnspan=2)
        self.export_recent_share_btn.grid(column=4, row=2, columnspan=2, sticky='e')
        
        
        self.tree = ttk.Treeview(op_frame, columns=('id', 'name', 'fid', 'result'), show='headings')
        self.tree.heading('id', text='编号', anchor='center')
        self.tree.heading('name', text='文件名称', anchor='center')
        self.tree.heading('fid', text='fid', anchor='center')
        self.tree.heading('result', text='分享结果', anchor='center')
        self.tree.column('id', width=50, anchor='center')
        self.tree.column('result', width=50, anchor='center')

        self.tree.grid(column=0, row=3, columnspan=9, pady=10, sticky='nsew')

        # 转存面板
        save_dname_label = ttk.Label(op_frame, text='转存目录', anchor='w')
        self.save_dname_var = StringVar()
        self.save_fname_entry = ttk.Entry(op_frame, textvariable=self.save_dname_var, width=15)
        save_delay_label = ttk.Label(op_frame, text='转存延迟', anchor='w')
        self.save_delay_var = StringVar()
        save_delay_entry = ttk.Entry(op_frame, textvariable=self.save_delay_var, width=self.widget_width)
        self.choice_file_btn = ttk.Button(op_frame, text='选择文件', width=self.widget_width)
        self.create_file_btn = ttk.Button(op_frame, text='生成模板', command='', width=self.widget_width)
        self.save_btn = ttk.Button(op_frame, text='批量转存', width=self.widget_width)
        self.save_share_btn = ttk.Button(op_frame, text='转存并分享')

        save_dname_label.grid(column=0, row=4)
        self.save_fname_entry.grid(column=1, row=4)
        save_delay_label.grid(column=2, row=4)
        save_delay_entry.grid(column=3, row=4)
        self.choice_file_btn.grid(column=4, row=4)
        self.create_file_btn.grid(column=5, row=4)
        self.save_btn.grid(column=6, row=4)
        self.save_share_btn.grid(column=7, row=4, columnspan=2, sticky='w')

        self.save_tree = ttk.Treeview(op_frame, columns=('id', 'url', 'share_res', 'save_res'), show='headings')
        self.save_tree.heading('id', text='编号', anchor='center')
        self.save_tree.heading('url', text='夸克链接', anchor='center')
        self.save_tree.heading('share_res', text='分享结果', anchor='center')
        self.save_tree.heading('save_res', text='保存结果', anchor='center')
        self.save_tree.column('id', width=50, anchor='center')
        self.save_tree.column('share_res', width=50, anchor='center')
        self.save_tree.column('save_res', width=50, anchor='center')

        self.save_tree.grid(column=0, row=5, columnspan=9, sticky='nsew')
        
        for item in op_frame.winfo_children():
            item.grid_configure(padx=2, pady=5)

    def set_controller(self, controller):
        '''
        设置控制器
        '''
        self.login_btn['command'] = controller.login
        self.share_btn['command'] = controller.share
        self.return_btn['command'] = controller.return_home
        self.return_prepage_btn['command'] = controller.return_prepage
        self.tree.bind('<<TreeviewSelect>>', controller.click)
        self.tree.bind('<Double-1>', controller.click_double)
        self.page_var.trace_add('write',controller.page_change)
        self.choice_file_btn['command'] = controller.openfile
        self.save_btn['command'] = controller.save_file
        self.save_share_btn['command'] = controller.save_and_share
        self.share_recent_save_btn['command'] = controller.save_and_share
        self.export_recent_share_btn['command'] = controller.save_and_share
        self.study_btn['command'] = controller.study

    def get_entries(self) -> dict:
        '''
        获取所有entry组件的值
        '''
        entries = {}
        entries['cookie'] = self.cookie_var.get()
        entries['dir_name'] = self.cur_dir_var.get()
        entries['pfid'] = self.pfid_var.get()
        entries['page'] = self.page_var.get()
        entries['size'] = self.page_count_var.get()
        entries['share_delay'] = self.share_delay_var.get()
        entries['save_dname'] = self.save_dname_var.get()
        entries['save_delay'] = self.save_delay_var.get()

        return entries

    def login(self, cookie:str, data:list) -> None:

        if cookie == '':
            messagebox.showerror(
                title='错误提示', 
                message='未检测到本地cookie\n未检测到输入cookie\n请到浏览器复制cookie，然后输入复制的内容')
            self.__update_log_interface('登录失败', 'danger')
        else:

            # 更新表数据
            if len(data) < 1:
                messagebox.showerror('错误提示', 'cookie错误，或网络错误，请检查！')
                self.__update_log_interface('登录失败！','danger')
            else:
                # 更新面板数据
                self.cookie_entry['state'] = 'normal'
                self.cur_dir_entry['state'] = 'normal'
                self.cur_pfid['state'] = 'normal'
                self.cookie_var.set(cookie)
                self.cur_dir_var.set('首页')
                self.pfid_var.set('0')
                self.page_var.set('1')
                self.page_count_var.set('50')
                self.save_delay_var.set(2)
                self.share_delay_var.set(5)
                # 清空表格
                self.__clear_tree_data(self.tree)
                self.__insert_data(data, self.tree)
                self.__update_log_interface('登录成功！')

                # 关闭面板修改操作
                self.login_btn['state'] = 'disabled'
                self.cookie_entry['state'] = 'disabled'
                self.cur_dir_entry['state'] = 'disabled'
                self.cur_pfid['state'] = 'disabled'

    def _fixed_map(self, option):
        '''
        修复3.7 3.8中treeview不能正常配置fg bg的bug
        通过调用 style.map("Treeview", query_opt=option) 来获取 Treeview 的当前风格设置，
        并返回该设置中除了 !disabled 和 !selected 的部分。
        这样你更改的前景色和背景色设置就不会在行被选中或禁用时被覆盖。
        然后，调用 style.map("Treeview", foreground=fixed_map("foreground"), background=fixed_map("background")) 以更新 Treeview 的风格设置
        '''
        return [elm for elm in self.style.map("Treeview", query_opt=option) if elm[:2] != ("!disabled", "!selected")]

    def __clear_tree_data(self, tree:object):
        # 清空TreeView
        for i in tree.get_children():
            tree.item(i, tags=())
            tree.delete(i)
    
    def __insert_data(self, data:list, tree:object):
        '''
        插入表格数据
        ::tree treeview对象
        '''
        total = 0
        for idx, item in enumerate(data):
            if item is None or isinstance(item, str):
                # savetree更新数据
                if not data:
                    self.error_tip('没有提取到有用的链接')
                    return
                tree.insert('', END, values=(idx, item, '', ''), tags=('tag', 'tag', 'tag','tag'+str(idx)))

            else:
                fid, filename, _, pfid, total = item
                tree.insert('', END, values=(idx, filename, fid, ''), tags=('tag', 'tag', 'tag', 'tag'+str(idx)))
            # 清除文字颜色
            tree.tag_configure("tag"+str(idx), foreground="")

        tree == self.tree and self.__update_log_interface(f'当前文件夹下共有 {total} 个文件！')

    def sub_directory(self, fname:str, file_type:bool, data:list):
        '''
        处理鼠标左键双击表格进入下级目录事件
        '''
        # 判断当前fid对应的数据类型，如果是文件，则不可点击
        if file_type:
            messagebox.showinfo('提示', f'{fname}-是文件，不可双击！！！')
            self.__update_log_interface('点击失败！','danger')
        else:
            
            # 空文件夹或者其他错误，直接返回
            if not data:
                messagebox.showinfo('提示', f'{fname}-是空文件夹，双击没用！！！')
                self.__update_log_interface('点击失败！','danger')
                return
            # 更新面板数据
            self.__clear_tree_data(self.tree)
            self.__insert_data(data, self.tree)

            self.cur_dir_entry['state'] = 'normal'
            self.cur_pfid['state'] = 'normal'
            self.cur_dir_var.set(fname)
            self.pfid_var.set(self.pfid_var.get() + '/' + data[0][-2])
            self.cur_dir_entry['state'] = 'disabled'
            self.cur_pfid['state'] = 'disabled'

    def next_page(self, data:list):
        ''''
        更新tree显示下一页内容
        '''
        self.__clear_tree_data(self.tree)
        self.__insert_data(data, self.tree)

    def return_home(self):
        # 返回首页
        if not self.cookie_var.get() or not self.cur_dir_var.get() or not self.pfid_var.get():
            self.__update_log_interface('请先登录！！！', 'danger')
        elif self.pfid_var.get() == '0':
            messagebox.showinfo('特别提示', '路已经走到尽头了，请往下走！！')
            return
        else:
            pass
    
    def return_prepage(self, pfid:str='', data:list=[]):
        '''
        返回上页
        '''
        if not self.cookie_var.get() or not self.cur_dir_var.get() or not self.pfid_var.get():
            self.__update_log_interface('请先登录！！！', 'danger')
            return
        if self.pfid_var.get() == '0':
            messagebox.showinfo('特别提示', '路已经走到尽头了，请往下走！！')
            return

        pfid_lst = pfid.split('/')
        # 空文件夹或者其他错误，直接返回
        if pfid == '0' or len(pfid_lst) == 1:
            messagebox.showinfo('提示', f'当前已经是首页了')
            self.__update_log_interface('点击失败！','danger')
            return

        # 更新面板数据
        self.__clear_tree_data(self.tree)
        self.__insert_data(data, self.tree)

        self.cur_dir_entry['state'] = 'normal'
        self.cur_pfid['state'] = 'normal'
        self.cur_dir_var.set('首页' if pfid_lst[-2] == '0' else '未知')
        self.pfid_var.set('/'.join(pfid_lst[:-1]))
        self.cur_dir_entry['state'] = 'disabled'
        self.cur_pfid['state'] = 'disabled'

    def update_tree_view(self, idx, res, fname, tree:object):
        '''
        更新数据显示
        ::res 返回的share url 或者 fid
        ::tree treeview [self.tree | self.save_tree]
        
        '''
        succ_tip = '分享成功' if tree == self.tree else '转存成功'
        fail_tip = '分享失败' if tree == self.tree else '转存失败'
        col_name = 'result' if tree == self.tree else 'save_res'

        if res:
            self.__update_log_interface(f'{succ_tip}--{fname}--{res}')
            row_id = tree.get_children()[idx]
            tree.set(row_id, col_name, '成功')
            tree.tag_configure("tag"+str(idx), foreground="green") #3.8 中并不起作用，3.10中可以正常工作
        else:
            if res is  None:
                self.__update_log_interface(f'{fail_tip}--{fname}', 'danger')
                row_id = tree.get_children()[idx]
                tree.set(row_id, col_name, '失败')
                tree.tag_configure("tag"+str(idx), foreground="red")

    def __update_log_interface(self, msg:str, msg_type:str='normal'):
        # 更新日志显示信息
        self.log_output['state'] = 'normal'
        self.log_output.insert(END, msg + '\n')

        self.log_output.tag_configure('danger', foreground='red')
        self.log_output.tag_configure('normal', foreground='green')
        end_line = str(int(self.log_output.index('end').split('.')[0]) - 2)

        if msg_type == 'danger':
            self.log_output.tag_add('danger', end_line + '.0', end_line + '.end')
        else:
            self.log_output.tag_add('normal', end_line + '.0', end_line + '.end')

        self.log_output['state'] = 'disabled'

    def update_savetree(self, data:list):
        if data:
            self.__clear_tree_data(self.save_tree)
            # self.save_tree.delete(*self.save_tree.get_children())
            for idx, item in enumerate(data):
                self.save_tree.insert('', END, values=(idx, item, '', ''), tags=('tag', 'tag', 'tag','tag'+str(idx)))
                self.save_tree.tag_configure("tag"+str(idx), foreground="")
        else:
            self.error_tip('没有提取到有用的链接')

    def error_tip(self, msg:str):
        messagebox.showerror('发生了错误', msg)
    
    def info_tip(self, msg:str):
        messagebox.showinfo('提示信息', msg)

    def pay_tip(self):
        messagebox.showwarning('功能未开发提示', '功能正在开发中，请稍候...')

class QuarkModel:
    def __init__(self) -> None:
        pass
    def get_datas(self, cookie:str, fid:str, page:str=1, size:str=50):
        self.share = QuarkShare(cookie)
        data = self.share.get_all_file(fid, page=page, size=size)
        return data
    
    # def get_share_url(self, fid, fname, is_file) -> str | None: 3.8 not support
    def get_share_url(self, fid, fname, is_file, succ_fname) -> str:
        '''
        succ_fname:: 分享结果保存的文件名
        '''
        return self.share.single_file_share(fid, fname, is_file, succ_fname)
    
    def get_tree_datas(self):
        '''
        获取treeview中的数据
        '''
        pass

class QuarkController:
    def __init__(self, model, view) -> None:
        self.model = model
        self.view = view
        self.data = []
        self.init_view()
        self.q = queue.Queue()
    
    def init_view(self):
        self.view.set_controller(self)

    def login(self):

        cookie = self.view.get_entries()['cookie']
        self.cookie = get_cookie(cookie)

        if not self.cookie:
            self.data = []
            self.view.login(self.cookie, self.data)
        else:
            # 对数据进行缓存
            self.data = self.model.get_datas(self.cookie, '0')
            self.view.login(self.cookie, self.data)

    def share(self):
        if not self.__is_login():
            self.view.error_tip('请登录！')
            return
        delay = self.view.get_entries()['share_delay']
        self.threads = []
        # 生成分享结果保存的文件名
        succ_fname = '批量分享--' + str(time.time()).split('.')[1] + '.txt'
        for idx, item in enumerate(self.data):
            fid, fname, is_file, _, total = item
            # 创建子线程进行数据请求
            thread = MyThread(target=self.__share_single_file, args=(fid, fname, is_file, idx, succ_fname))
            self.threads.append(thread)
        # 再创建一个子线程来管理数据请求线程的开启时间
        self.lauch_thread = threading.Thread(target=self.__thread_manager, args=(self.threads, delay))
        self.lauch_thread.start()
        threading.Thread(target=self.update).start()

    def update(self):
        '''
        控制分享，使用after方法循环更新treeview
        '''
        self.view.return_btn['state'] = 'disabled'
        self.view.page_entry['state'] = 'disabled'
        self.view.return_prepage_btn['state'] = 'disabled'
        self.view.share_btn['state'] = 'disabled'

        self.cancel_id = self.view.root.after(2000, self.update)

        if self.lauch_thread.is_alive() or not self.q.empty():
            item = self.q.get()
            if not isinstance(item, threading.Thread):
                idx, is_share, fname = item
                self.view.update_tree_view(idx, is_share, fname, self.view.tree)
                if idx == len(self.data) -1:
                    self.view.root.after_cancel(self.cancel_id)
                    self.view.info_tip('分享完成！')
                    self.view.return_btn['state'] = 'normal'
                    self.view.page_entry['state'] = 'normal'
                    self.view.return_prepage_btn['state'] = 'normal'
                    self.view.share_btn['state'] = 'normal'

    def return_home(self):
        # 未登录
        if not self.__is_login():
            self.view.error_tip('请登录！')
            self.view.return_home()
        # 已登录，并且在首页
        elif self.__is_login and self.view.get_entries()['pfid'] == '0':
            self.view.return_home()
        else:
            self.login()

    def return_prepage(self):
        entries = self.view.get_entries()
        if not self.__is_login():
            self.view.error_tip('请登录！')
            self.view.return_prepage()
        elif entries['pfid'] == '0':
            # 已经在首页了
            self.view.return_prepage('0', [])
        else:
            pfid_lst = entries['pfid'].split('/')
            pfid = pfid_lst[-2]
            self.data = self.model.get_datas(self.cookie, pfid, entries['page'], entries['size'])
            self.view.return_prepage('/'.join(pfid_lst), self.data)

    def click_double(self,event):
        '''
        treeview 鼠标双击事件
        '''
        # 双击空表格会报错

        try:
            selected = event.widget.selection()[0]
            values = event.widget.item(selected)['values']
            idx ,fname, fid, _ = values
            file_type = self.data[idx][2]
        except:
            return
        else:
            if file_type:
                # 文件不可双击
                self.view.update(fname, file_type, self.data)
            else:
                # 文件夹可以点击
                page = self.view.page_var.get()
                size = self.view.page_count_var.get()
                # 空文件夹会返回空数据
                data = self.model.get_datas(self.cookie, fid, page, size)
                # 如果返回数据不为空，则挂载在self，如果为空，则原始数据不变
                self.data = data or self.data
                self.view.sub_directory(fname, file_type, data)

    def click(self,event):
        if len(event.widget.selection()) > 1:
            messagebox.showwarning('很难办！！', '你同时选择了多个文件夹，这让我很难办！！！')
        try:
            # 表格项目双击也会触发选中事件，双击后会清空数据，有冲突，不影响
            selected = event.widget.selection()[0]
        except IndexError:
            pass
        else:
            values = event.widget.item(selected)['values']
            idx ,fname, fid, _ = values
            self.view.save_dname_var.set(fname)

    def page_change(self, *args):
        '''
        检测page输入框的改变，来获取数据
        '''
        entries = self.view.get_entries()
        page = entries['page']
        size = entries['size']
        
        if not self.__is_login():
            # 判断当前是否登录
            # self.view.error_tip('宝儿，请登录')
            return
        
        total = self.data[0][-1]
        pfid = self.data[0][-2]
        pages = math.ceil(total / int(size))
        # 有bug，暂时做判断解决，这个地方会trace两次，一次会返回空值
        if not page:
            return
        if page and pages < int(page):
            self.view.error_tip(f'总共{total}条数据，最大页数为{pages}')
            self.view.page_var.set(str(pages))
        else:
            self.data = self.model.get_datas(self.cookie, pfid, page, size)
            self.view.next_page(self.data)

    def __share_single_file(self, fid, fname, is_file, idx, succ_fname):
        # idx,放入索引，用于追踪当前数据在treeview中的位置
        is_share = self.model.get_share_url(fid, fname, is_file, succ_fname)
        self.q.put((idx, is_share, fname))

    # def __thread_manager(self, threads:list, delay:str | int =2): 3.8 not support
    def __thread_manager(self, threads:list, delay:str=2):
        '''
        用于控制网络请求线程的开启时间
        '''

        for thread in threads:
            thread.start()
            # 将开启的线程也加入到队列中
            self.q.put(thread)
            time.sleep(int(delay))
    
    def __is_login(self):
        # 如果登录成功，空文件夹是不允许做双击操作的，tree的内容可以用作判断是否登录
        entries = self.view.get_entries()
        tree_lst = self.view.tree.get_children()
        return all([entries['cookie'], entries['dir_name'], entries['pfid'], tree_lst])

    def extract_url(self, text):
        try:
            url = re.findall(r'http[s]?://(?:[a-zA-Z]|[0-9]|[$-_@.&+]|[!*\\(\\),]|(?:%[0-9a-fA-F][0-9a-fA-F]))+', text)[0]
        except:
            return None
        return url
    
    def openfile(self):
        
        filename = filedialog.askopenfilename()
        data = []
        if not filename:
            return
        with open(filename, 'r', encoding='utf8') as f:
            lines = f.readlines()        
        for line in lines:
            line = self.extract_url(line)
            if line and 'quark.cn' in line:
                data.append(line)
        if data:
            # 缓存一下数据
            self.save_tree_data = data
        self.view.update_savetree(data)

    def save_file(self):

        self.threads = []

        if not self.__is_login():
            self.view.error_tip('请登录')
            return
        else:
            try:
                pfid_id = self.view.tree.selection()[0]
                _, _, pfid, _ = self.view.tree.item(pfid_id)['values']
            except IndexError:
                self.view.error_tip('请选择要保存到哪个文件夹，\n单击目录即可')
                return

        delay = self.view.get_entries()['save_delay']
        for idx, item in enumerate(self.save_tree_data):
            pwd_id = item.split('/')[-1]
            # 创建子线程进行数据请求
            thread = MyThread(target=self.save_single_file, args=(pwd_id, pfid, idx))
            self.threads.append(thread)
        # 再创建一个子线程来管理数据请求线程的开启时间
        self.lauch_thread = threading.Thread(target=self.__thread_manager, args=(self.threads, delay))
        self.lauch_thread.start()
        threading.Thread(target=self.update_save_tree).start()

    def update_save_tree(self):
        '''
        控制分享，使用after方法循环更新treeview
        '''
        self.view.return_btn['state'] = 'disabled'
        self.view.page_entry['state'] = 'disabled'
        self.view.return_prepage_btn['state'] = 'disabled'
        self.view.share_btn['state'] = 'disabled'
        self.view.choice_file_btn['state'] = 'disabled'
        self.view.create_file_btn['state'] = 'disabled'
        self.view.save_btn['state'] = 'disabled'
        self.view.save_share_btn['state'] = 'disabled'

        self.cancel_id = self.view.root.after(2000, self.update_save_tree)

        if self.lauch_thread.is_alive() or not self.q.empty():
            item = self.q.get()
            if not isinstance(item, threading.Thread):
                print(item)
                idx, fid, fname = item
                print('idx',idx)
                self.view.update_tree_view(idx, fid, fname, self.view.save_tree)
                if idx == len(self.save_tree_data) -1:
                    self.view.root.after_cancel(self.cancel_id)
                    self.view.info_tip('转存完成！')
                    self.view.return_btn['state'] = 'normal'
                    self.view.page_entry['state'] = 'normal'
                    self.view.return_prepage_btn['state'] = 'normal'
                    self.view.share_btn['state'] = 'normal'
                    self.view.choice_file_btn['state'] = 'normal'
                    self.view.create_file_btn['state'] = 'normal'
                    self.view.save_btn['state'] = 'normal'
                    self.view.save_share_btn['state'] = 'normal'

    def save_single_file(self, pwd_id, to_dir_fid, idx):
        save = QuarkSave(self.cookie)
        fid, fname, is_file = save.autosave(pwd_id, to_dir_fid)
        self.q.put((idx, fid, fname))

    def save_and_share(self):
        self.view.pay_tip()
    
    def study(self):
        import webbrowser
        webbrowser.open('https://kdocs.cn/l/clkp0NPLizug')


