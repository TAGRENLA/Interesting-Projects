import time
import json
import random

from common import request, common_params, logger


class QuarkSave:
    def __init__(self, cookie:str, proxy:str='') -> None:
        self.cookie = cookie
        self.proxy = proxy
        self.ss = request(self.cookie, self.proxy)
        self.logger = logger()
        self.base_url = 'https://drive-pc.quark.cn/1/clouddrive/share/sharepage/'
        self.common_params = common_params()


    def get_stoken(self, pwd_id:str):
        url = self.base_url + 'token'
        params = common_params()
        data = {
            'passcode':'', 
            'pwd_id':pwd_id
        }
        res = self.ss.post(url, data=json.dumps(data), params=params)
        resdata = res.json()
        if res.status_code == 200 and resdata['code'] == 0:
            stoken = resdata['data']['stoken']
            print(stoken)
            return stoken
        else:
            self.logger.error(resdata['message'])
            print(resdata)

    def get_fid_token(self, pwd_id:str , stoken:str) -> tuple:
        '''
        获取ftoken
        '''
        url = self.base_url + 'detail'

        params = {
            'pwd_id':pwd_id, 
            'stoken':stoken, 
            'pdir_fid':0, 
            'force':0, 
            '_page':1, 
            '_size':50, 
            '_fetch_banner':1, 
            '_fetch_share':1, 
            '_fetch_total':1, 
            '_sort':'file_type:asc, updated_at:desc'
        }
        params.update(self.common_params)
        res = self.ss.get(url, params=params)
        resdata = res.json()
        if res.status_code == 200 and resdata['code'] == 0:
            data = resdata['data']
            share_fid_token = data['list'][0]['share_fid_token']
            fid = data['list'][0]['fid']
            print(share_fid_token)
            # 返回文件详情信息，供调用
            return (share_fid_token, fid, data)
        else:
            self.logger.error(resdata['message'])
            print(resdata)


    def file_save(self, fid, ftoken, stoken, to_pdir_fid, pwd_id):
        '''
        保存文件
        '''
        url = self.base_url + 'save'

        params = self.common_params
        data = {
            'fid_list':[fid], 
            'fid_token_list':[ftoken], 
            'to_pdir_fid':to_pdir_fid, 
            'pwd_id':pwd_id, 
            'stoken':stoken, 
            'pdir_fid':'0', 
            'scene':'link'
        }
        res = self.ss.post(url, data=json.dumps(data), params=params)
        resdata = res.json()
        
        if res.status_code == 200 and resdata['code'] == 0:
            task_id = resdata['data']['task_id']
            print('task_id', task_id)
            return task_id
        elif res.status_code == 404:
            self.logger.error(resdata['message'])
        else:
            self.logger.error(resdata['message'])
            print(resdata)

    def get_save_result(self, task_id:str):
        '''
        获取结果
        status==2 为保存成功
        '''
        url = 'https://drive-pc.quark.cn/1/clouddrive/task'

        params = {
            'task_id':task_id, 
            'retry_index':0
        }
        params.update(self.common_params)
        retry_times = 100
        # 结果需要多次获取
        for i in range(retry_times):
            params['retry_index'] = i
            res = self.ss.get(url, params=params)
            resdata = res.json()
            if res.status_code == 200 and resdata['code'] == 0:
                data = resdata['data']
                status = data['status']
                if status == 2:
                    fid = data['save_as']['save_as_top_fids'][0]
                    print('success')
                    return fid
                else:
                    print(f'获取返回结果失败，正在进行第{i}尝试')
            else:
                self.logger.error(resdata['message'])
                print(resdata)
                return None
            # break
            time.sleep(0.8)

    def main(self, pwd_id:str, to_dir_fid:str, delay:int=2) -> tuple:
        
        print(f'正在保存---{pwd_id}')
        stoken = self.get_stoken(pwd_id)
        ftoken, fid, detail = self.get_fid_token(pwd_id, stoken)
        task_id = self.file_save(fid, ftoken, stoken, to_dir_fid, pwd_id)
        fid = self.get_save_result(task_id)
        file_name = detail['list'][0]['file_name']
        is_file = detail['list'][0]['file']
        # time.sleep(delay)
        return (fid, file_name, is_file)

if __name__ == '__main__':
    # 代理ip
    # 代理功能我只在这个文件中进行了单独设置，如果需要在操作界面中实现代理，请修改```quarkmvc.py```中的相关代码
    proxy = '218.6.120.111:7777'
    cookie = '_UP_A4A_11_=wb963151bc7a4e05a1bdf1d2d1427560; _UP_BT_=html5; _UP_D_=mobile; tfstk=fMxIM-9JkWVCBE91ZwHNfMmtM_jSgBiqd86JnLEUeMIL2Q9l_9zE-alW5QdN9HuhTC1W3LqPTpSKFQOvOaRWEvXRwQd5aeuZ0pvhqghVVmo2KtgyPMtC27JO7HX7Kjoq0pecI9aigY4L1v5PegBdy_CtCTWl2TCpw1QOHtPd2gdJBA6PnTB82wFOXTWrwGGhID1Ddboi3-7QSYRA1uE7F9_dMmf_2uK1dd1vpqE82h6CR3J6U3tA8UpcoHJoVljehFIO3pmQfipdhB5wMmE1XdJ9aZYiZo7M13_Dvw2-MsQ5OFKd58EJIG15zUOIOyfp8C_cBNeSmORV6pxp5YV9pI5CvOQZDx9OyF-hoHlTAiLDLM8JZqzGALLdfg5Q0sixBzal9uB1gAM_rz-PI34nkOzZDwBGQ3HsCzRlJOX1gAM_rzbdIO--CAayZ; __pus=fd55ca27e52b125b8b51e1d229125054AATWoNOUsFv4pDu2UO/Hz9JDmByNy9DpZfn2miQ9E/fTXWhYQnuRNizLI03m5ZRukmoAIG9dOv4fbVMXjcIPLqDy; __kp=24d28940-112e-11ef-acb4-071bc346acfd; __kps=AASE6NBAlN0nQGqp9ctRsVAB; __ktd=DjeBWm4xVMJOoWymzEdL5w==; __uid=AASE6NBAlN0nQGqp9ctRsVAB; __puus=7fcd09505c2473ed4b1205a02667dc4aAARRVri+vyWCbJRflFE3NCfPzDcQONMidFbOg6ZL0Ku7uTUTZhLtTjfwPM5r1z9ArgWVkPewrSBwXpd1hfV3REYaoVTpy/lbRxZycXXUZOywI7jl+NtrTqGabbtJJxXsbr8dE2JZMV7PPQkQCNwcPV9RqjkqydsyTunyhemCA2vGU8WDttWUtm4LJJXhpve7st4ahUQudZ8eTX2JpjdfELFu'
    pwd_id = '619030698818'
    to_dir_fid = '2becb37004bc453bbf5156b7f64cad19'
    autosave = QuarkSave(cookie, proxy)
    autosave.main(pwd_id,to_dir_fid)