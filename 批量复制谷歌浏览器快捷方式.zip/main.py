import os
import shutil

# 源文件路径
source_path = r'E:\Users\TAGRENLA\Desktop\Google Chrome.lnk'


# 目标文件夹路径
target_dir = r'E:\Users\TAGRENLA\Desktop\Google222'

# 确保目标文件夹存在
if not os.path.exists(target_dir):
    os.makedirs(target_dir)

# 循环从3到100，为每个数字创建一个快捷方式副本
for i in range(101, 1001):
    # 为每个副本创建一个唯一的文件名
    target_path = os.path.join(target_dir, f'Google Chrome - {i} - .lnk')
    # 复制文件
    shutil.copy(source_path, target_path)

print(f'完成复制，总共创建了{range(3, 101).stop - range(3, 101).start}个副本。')
