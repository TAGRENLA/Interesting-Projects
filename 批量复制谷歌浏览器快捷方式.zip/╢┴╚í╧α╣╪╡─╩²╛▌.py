import os
import win32com.client

# 目标文件夹路径，包含需要读取目标属性的快捷方式
target_dir = r'E:\Users\TAGRENLA\Desktop\Google'

# 创建COM对象
shell = win32com.client.Dispatch('WScript.Shell')

# 遍历目标目录中的所有文件
for filename in os.listdir(target_dir):
    if filename.endswith(".lnk"):  # 确保只处理快捷方式文件
        # 构造快捷方式的完整路径
        shortcut_path = os.path.join(target_dir, filename)

        # 读取快捷方式
        shortcut = shell.CreateShortCut(shortcut_path)

        # 输出快捷方式的详细属性
        print(f"快捷方式名称: {filename}")
        print(f"目标路径: {shortcut.TargetPath}")
        print(f"参数: {shortcut.Arguments}")
        print(f"工作目录: {shortcut.WorkingDirectory}")
        print(f"窗口样式: {shortcut.WindowStyle}")
        print(f"快捷键: {shortcut.Hotkey}")
        print(f"图标路径: {shortcut.IconLocation}")
        print(f"描述: {shortcut.Description}")
        # 如果有其他需要，可以继续添加属性输出

        print("----------")
