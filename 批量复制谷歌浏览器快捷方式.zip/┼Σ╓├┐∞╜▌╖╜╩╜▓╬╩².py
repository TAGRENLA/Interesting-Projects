import os
import re
import win32com.client

# 目标文件夹路径
target_dir = r'E:\Users\TAGRENLA\Desktop\Google222'

# 创建COM对象
shell = win32com.client.Dispatch('WScript.Shell')

# 正则表达式，匹配快捷方式名称中的数字
pattern = re.compile(r'Google Chrome - (\d+) -')

# 遍历目标目录中的所有快捷方式文件
for filename in os.listdir(target_dir):
    if filename.endswith(".lnk"):
        # 找到文件名中的数字部分
        match = pattern.search(filename)
        if match:
            number = match.group(1)  # 获取匹配到的数字
            # 构造新的参数值
            new_argument = f"--user-data-dir=E:\\Users\\谷歌浏览器多开缓存\\{number}"

            # 构造快捷方式的完整路径
            shortcut_path = os.path.join(target_dir, filename)

            # 读取快捷方式对象
            shortcut = shell.CreateShortCut(shortcut_path)

            # 更新参数
            shortcut.Arguments = new_argument

            # 保存快捷方式
            shortcut.save()

            print(f"快捷方式 '{filename}' 已更新参数为：{new_argument}")
        else:
            print(f"快捷方式 '{filename}' 不包含数字，参数未更新。")

print("所有快捷方式的参数更新完毕。")
